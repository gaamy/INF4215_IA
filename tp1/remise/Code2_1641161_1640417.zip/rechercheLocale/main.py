from AlgorithmeRecuitState import AlgorithmeRecuitState
from simulated_annealing import *

class SolutionArboressante:
	def search(self,Positions,K=200,C=1,timeout=3600*24,debug=False):

		initialState = AlgorithmeRecuitState(Positions,K,C)
		start = time.time()
		q = AlgorithmeRecuitState(positionDesAntennes,200,1)
		end = 0
		bestnode = Node(q)
		bestnode.f = 1000000000000000
		while end-start < 10:
			node = simulated_annealing_search(q,0.1,0.01,100,debug)
			while node == None:
				print "Restart..."
				q = AlgorithmeRecuitState(positionDesAntennes, 200, 1)
				node = simulated_annealing_search(q,0.1,0.01,100,debug)

			if node.f < bestnode.f:
				bestnode = node
				q = AlgorithmeRecuitState(positionDesAntennes, 200, 1)
			end = time.time()
		end = time.time()

		if debug:
			print '{} seconds'.format(end-start)

		finalAntennas = []
		for antenna in bestnode.state.antennaList:
			finalAntennas.append((antenna.position.x,antenna.position.y,antenna.radius))
		return finalAntennas

p = SolutionArboressante()
positionDesAntennes = ([(30,0),(10,10),(20,20),(30,40),(50,40)])
print p.search(positionDesAntennes,200,1,timeout=10,debug= False)