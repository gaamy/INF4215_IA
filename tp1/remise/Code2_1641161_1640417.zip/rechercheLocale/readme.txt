pour exécuter l’algorithme de recherche locale utilisez le fichier main.py

la fonction search(Positions,K,C,timeout) retourne la solution

timeout est le temps en secondes que l’algorithme vas continuer a chercher