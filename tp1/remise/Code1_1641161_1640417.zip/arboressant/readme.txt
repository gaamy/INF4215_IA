pour exécuter l’algorithme de recherche arborescente utilisez le fichier main.py

la fonction search(Positions,K,C) retourne la solution