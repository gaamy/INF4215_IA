from AntennaState import AntennaState
from astar_search import *

class SolutionArboressante:
	def search(self,Positions,K=200,C=1,debug=False):
		initialState = AntennaState(Positions,K,C,time.time())
		solution = astar_search(initialState,debug)
		finalAntennas = []
		for antenna in solution.state.antennaList:
			finalAntennas.append((antenna.position.x,antenna.position.y,antenna.radius))
		return finalAntennas

p = SolutionArboressante()
positionDesAntennes = ([(30,0),(10,10),(20,20),(30,40),(50,40)])
print p.search(positionDesAntennes,200,1,debug= False)